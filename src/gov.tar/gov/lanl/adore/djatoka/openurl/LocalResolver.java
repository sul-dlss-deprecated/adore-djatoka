/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.lanl.adore.djatoka.openurl;

import gov.lanl.adore.djatoka.util.ImageRecord;
import info.openurl.oom.entities.Referent;
import java.io.File;
import java.util.Properties;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jdeering
 */
public class LocalResolver implements IReferentResolver{

    @Override
    public ImageRecord getImageRecord(String rftId) throws ResolverException {
        System.out.print("file\n");
        String id=rftId;
        String rft=id.replace("file://", "");
        return new ImageRecord(rftId,rftId.replace("file://", ""));
    }

    @Override
    public ImageRecord getImageRecord(Referent rft) {
        return new ImageRecord(rft.toString(),rft.toString().replace("file://", ""));
    }

    @Override
    public void setProperties(Properties props) throws ResolverException {
        
    }

    @Override
    public int getStatus(String rftId) {
       File target=new File(rftId.replace("file://", ""));
       if (target.exists())
           return HttpServletResponse.SC_OK;
       else
           return HttpServletResponse.SC_NOT_FOUND;
                   
    }

    @Override
    public IReferentMigrator getReferentMigrator() {
        return null;
    }
    
}
